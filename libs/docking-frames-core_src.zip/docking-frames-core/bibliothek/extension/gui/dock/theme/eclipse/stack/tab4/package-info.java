/**
 * Classes that give the {@link bibliothek.extension.gui.dock.theme.EclipseTheme} a look
 * identicall to Eclipse 4.x.
 */
package bibliothek.extension.gui.dock.theme.eclipse.stack.tab4;