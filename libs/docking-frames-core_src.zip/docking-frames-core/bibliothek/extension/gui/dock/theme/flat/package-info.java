/**
 * Various graphical and logical components needed to paint the layout
 * when {@link bibliothek.extension.gui.dock.theme.FlatTheme} is active.
 */
package bibliothek.extension.gui.dock.theme.flat;