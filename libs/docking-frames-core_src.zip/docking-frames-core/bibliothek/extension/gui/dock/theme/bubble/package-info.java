/**
 * Various graphical and logical components used when 
 * {@link bibliothek.extension.gui.dock.theme.BubbleTheme} is
 * active.
 */
package bibliothek.extension.gui.dock.theme.bubble;