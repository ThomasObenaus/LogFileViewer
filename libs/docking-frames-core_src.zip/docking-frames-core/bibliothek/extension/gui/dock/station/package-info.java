/**
 * Contains extensions to the {@link bibliothek.gui.DockStation}s. These 
 * extensions are usually disabled.
 */
package bibliothek.extension.gui.dock.station;