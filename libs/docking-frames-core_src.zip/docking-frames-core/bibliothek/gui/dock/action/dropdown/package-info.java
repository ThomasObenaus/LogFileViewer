/**
 * Elements needed to design the communication between a
 * {@link bibliothek.gui.dock.action.DropDownAction} and its children. 
 */
package bibliothek.gui.dock.action.dropdown;