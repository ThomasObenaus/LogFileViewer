/**
 * Contains the popup-menu that is usually shown when the user right clickes
 * on a {@link bibliothek.gui.Dockable} or a {@link bibliothek.gui.dock.title.DockTitle}.
 */
package bibliothek.gui.dock.action.popup;