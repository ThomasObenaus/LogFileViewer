/**
 * The perspective API allows clients to access and modify the layout without
 * actually creating any {@link bibliothek.gui.Dockable}s.
 */
package bibliothek.gui.dock.perspective;