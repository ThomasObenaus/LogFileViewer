/**
 * Various implementations of {@link bibliothek.gui.dock.control.relocator.RelocateOperation}. These
 * operations are executed by the {@link bibliothek.gui.dock.control.relocator.DefaultDockRelocator} once the user
 * finishes a drag and drop operation. 
 */
package bibliothek.gui.dock.control.relocator;
