/**
 * Elements that can be used in any application using DockingFrames.
 */
package bibliothek.gui.dock.facile;