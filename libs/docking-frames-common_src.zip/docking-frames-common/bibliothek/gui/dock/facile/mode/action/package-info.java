/**
 * A set of {@link bibliothek.gui.dock.action.DockAction}s that change the {@link bibliothek.gui.dock.facile.mode.LocationMode} 
 * of a {@link bibliothek.gui.Dockable}.
 */
package bibliothek.gui.dock.facile.mode.action;