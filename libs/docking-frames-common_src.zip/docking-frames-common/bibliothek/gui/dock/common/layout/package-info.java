/**
 * Classes to manage how space is distributed between {@link bibliothek.gui.Dockable}s.
 */
package bibliothek.gui.dock.common.layout;