/**
 * Various listeners and adapters that can be added to {@link bibliothek.gui.dock.common.CControl}, 
 * {@link bibliothek.gui.dock.common.intern.CDockable} and other classes associated with them.
 */
package bibliothek.gui.dock.common.event;