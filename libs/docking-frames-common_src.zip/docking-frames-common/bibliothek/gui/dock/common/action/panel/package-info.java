/**
 * Supporting classes for {@link bibliothek.gui.dock.common.action.CPanelPopup}.
 */
package bibliothek.gui.dock.common.action.panel;