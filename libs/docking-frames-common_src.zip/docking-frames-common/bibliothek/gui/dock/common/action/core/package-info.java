/**
 * A set of {@link bibliothek.gui.dock.action.DockAction}s that also implement
 * {@link bibliothek.gui.dock.common.action.core.CommonDockAction}. These actions are used to feed the {@link bibliothek.gui.dock.common.action.CAction}s.
 */
package bibliothek.gui.dock.common.action.core;