/**
 * Contains the {@link bibliothek.gui.dock.common.intern.station.CommonDockStation}, various implementations of {@link bibliothek.gui.dock.common.intern.station.CommonDockStation} and supporting classes. 
 */
package bibliothek.gui.dock.common.intern.station;