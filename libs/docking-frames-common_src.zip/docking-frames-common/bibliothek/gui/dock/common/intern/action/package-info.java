/**
 * {@link bibliothek.gui.dock.common.action.CAction}s and supporting classes that are not intended for clients
 * to be used directly. Clients should prefer using the classes from the package <code>bibliothek.gui.dock.common.action</code>.
 */
package bibliothek.gui.dock.common.intern.action;