/**
 * Implementation of a {@link bibliothek.gui.dock.frontend.LayoutChangeStrategy} and supporting classes. The
 * strategy in this package pays special attention to {@link bibliothek.gui.dock.common.MultipleCDockable}s.
 */
package bibliothek.gui.dock.common.intern.layout;