/**
 * The perspective API offers clients the possibility to define or modify the layout
 * of an application without actually creating any {@link bibliothek.gui.dock.common.intern.CDockable}s.
 */
package bibliothek.gui.dock.common.perspective;