/**
 * This module of the perspective API allows clients to access and modify
 * {@link bibliothek.gui.dock.common.intern.CDockable}s that are in different modes like "maximized" or "minimized".
 */
package bibliothek.gui.dock.common.perspective.mode;