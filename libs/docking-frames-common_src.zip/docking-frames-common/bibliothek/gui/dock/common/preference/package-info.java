/**
 * Classes used directly or indirectly by the {@link bibliothek.gui.dock.common.CPreferenceModel}. These classes
 * can also be used by clients to create their custom {@link bibliothek.extension.gui.dock.preference.PreferenceModel}.
 */
package bibliothek.gui.dock.common.preference;