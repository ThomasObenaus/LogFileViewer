#!/bin/bash
echo "Starting LogFileViewer"
java -jar LogFileViewer.jar

