LogFileViewer
=============

The LogFileViewer is a small tool for reading and displaying the contents of logfiles in a more useful/readable way. On writing plugins for a software that supports logging you are able to provide a more informative view of the log contents than the plain textual one. The goal is to use the knowledge about the meaning of the loglines and to show it to other users in a way they can understand.
