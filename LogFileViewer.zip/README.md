LogFileViewer
=============

Tool for displaying contents of logfiles in a reworked/usefull view
